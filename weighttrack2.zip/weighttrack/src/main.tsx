import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App'
import { WeightProvider } from './store/WeightContext'
import { ToastProvider } from './components/Toast'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <WeightProvider>
      <ToastProvider>
        <App />
      </ToastProvider>
    </WeightProvider>
  </StrictMode>,
)
