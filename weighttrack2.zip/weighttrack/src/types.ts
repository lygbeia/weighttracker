export type Unit = 'kg' | 'lb'
/** Día en que empieza la semana (0 = domingo, 1 = lunes, 6 = sábado). */
export type WeekStart = 0 | 1 | 6
export type Tab = 'inicio' | 'registrar' | 'stats' | 'historial' | 'config'

/** Los pesos se guardan SIEMPRE en kg; la unidad solo afecta la visualización. */
export interface WeightEntry {
  date: string // YYYY-MM-DD
  kg: number
  demo?: boolean
  updatedAt: number
}

export interface Settings {
  unit: Unit
  weekStart: WeekStart
}

export interface WeekSummary {
  start: string
  end: string
  count: number
  avg: number
  min: number
  max: number
  entries: WeightEntry[]
}
