import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import type { Settings, WeightEntry } from '../types'
import * as db from '../lib/db'
import { generateDemo } from '../lib/demo'
import { todayISO } from '../lib/dates'

const DEFAULT_SETTINGS: Settings = { unit: 'kg', weekStart: 1 }

const sortAsc = (l: WeightEntry[]) =>
  [...l].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0))

const merge = (prev: WeightEntry[], incoming: WeightEntry[]) => {
  const m = new Map(prev.map((e) => [e.date, e]))
  incoming.forEach((e) => m.set(e.date, e))
  return sortAsc([...m.values()])
}

interface Ctx {
  entries: WeightEntry[] // orden ascendente por fecha
  settings: Settings
  ready: boolean
  error: string | null
  hasDemo: boolean
  upsert: (date: string, kg: number) => Promise<void>
  remove: (date: string) => Promise<void>
  importEntries: (rows: { date: string; kg: number }[]) => Promise<void>
  replaceAll: (entries: WeightEntry[], settings?: Settings | null) => Promise<void>
  clearAll: () => Promise<void>
  loadDemo: () => Promise<number>
  removeDemo: () => Promise<void>
  updateSettings: (patch: Partial<Settings>) => Promise<void>
}

const WeightCtx = createContext<Ctx | null>(null)

export function WeightProvider({ children }: { children: ReactNode }) {
  const [entries, setEntries] = useState<WeightEntry[]>([])
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS)
  const [ready, setReady] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const [e, s] = await Promise.all([db.getAllEntries(), db.getSettings()])
        if (!alive) return
        setEntries(sortAsc(e))
        if (s) setSettings({ ...DEFAULT_SETTINGS, ...s })
        // Pide al navegador que no borre los datos por falta de espacio.
        navigator.storage?.persist?.().catch(() => {})
      } catch {
        if (alive)
          setError(
            'No se pudo abrir el almacenamiento local. Revisá que el navegador no esté en modo privado.',
          )
      } finally {
        if (alive) setReady(true)
      }
    })()
    return () => {
      alive = false
    }
  }, [])

  const upsert = useCallback(async (date: string, kg: number) => {
    const entry: WeightEntry = { date, kg, updatedAt: Date.now() } // al guardar deja de ser "demo"
    await db.putEntries([entry])
    setEntries((prev) => merge(prev, [entry]))
  }, [])

  const remove = useCallback(async (date: string) => {
    await db.deleteEntries([date])
    setEntries((prev) => prev.filter((e) => e.date !== date))
  }, [])

  const importEntries = useCallback(async (rows: { date: string; kg: number }[]) => {
    const now = Date.now()
    const list: WeightEntry[] = rows.map((r) => ({ date: r.date, kg: r.kg, updatedAt: now }))
    await db.putEntries(list)
    setEntries((prev) => merge(prev, list))
  }, [])

  const replaceAll = useCallback(async (list: WeightEntry[], s?: Settings | null) => {
    await db.replaceEntries(list)
    setEntries(sortAsc(list))
    if (s) {
      await db.saveSettings(s)
      setSettings(s)
    }
  }, [])

  const clearAll = useCallback(async () => {
    await db.clearEntries()
    setEntries([])
  }, [])

  const loadDemo = useCallback(async () => {
    const existing = new Set(entries.map((e) => e.date))
    const list = generateDemo(todayISO()).filter((e) => !existing.has(e.date)) // nunca pisa datos reales
    await db.putEntries(list)
    setEntries((prev) => merge(prev, list))
    return list.length
  }, [entries])

  const removeDemo = useCallback(async () => {
    const dates = entries.filter((e) => e.demo).map((e) => e.date)
    await db.deleteEntries(dates)
    setEntries((prev) => prev.filter((e) => !e.demo))
  }, [entries])

  const updateSettings = useCallback(
    async (patch: Partial<Settings>) => {
      const next = { ...settings, ...patch }
      await db.saveSettings(next)
      setSettings(next)
    },
    [settings],
  )

  const value = useMemo<Ctx>(
    () => ({
      entries,
      settings,
      ready,
      error,
      hasDemo: entries.some((e) => e.demo),
      upsert,
      remove,
      importEntries,
      replaceAll,
      clearAll,
      loadDemo,
      removeDemo,
      updateSettings,
    }),
    [entries, settings, ready, error, upsert, remove, importEntries, replaceAll, clearAll, loadDemo, removeDemo, updateSettings],
  )

  return <WeightCtx.Provider value={value}>{children}</WeightCtx.Provider>
}

export function useWeight(): Ctx {
  const c = useContext(WeightCtx)
  if (!c) throw new Error('useWeight debe usarse dentro de WeightProvider')
  return c
}
