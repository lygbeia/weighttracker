import { useState } from 'react'
import type { Tab } from './types'
import { useWeight } from './store/WeightContext'
import BottomNav from './components/BottomNav'
import { IconButton } from './components/ui'
import { ScaleIcon, SlidersIcon } from './components/Icons'
import Dashboard from './pages/Dashboard'
import Register from './pages/Register'
import Stats from './pages/Stats'
import History from './pages/History'
import Settings from './pages/Settings'

export default function App() {
  const { ready, error } = useWeight()
  const [tab, setTab] = useState<Tab>('inicio')
  const [editDate, setEditDate] = useState<string | null>(null)

  const go = (t: Tab) => {
    setTab(t)
    window.scrollTo({ top: 0 })
  }

  return (
    <div className="min-h-screen bg-bg text-white">
      <header
        className="sticky top-0 z-20 bg-bg/85 backdrop-blur-md border-b border-line/50"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="mx-auto max-w-3xl flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-2">
            <span className="h-8 w-8 rounded-xl bg-accent/15 text-accent flex items-center justify-center">
              <ScaleIcon width={18} height={18} />
            </span>
            <span className="font-bold tracking-tight">WeightTrack</span>
          </div>
          <IconButton
            label="Configuración"
            onClick={() => go('config')}
            className={tab === 'config' ? '!text-accent' : ''}
          >
            <SlidersIcon />
          </IconButton>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-5 pb-32">
        {!ready ? (
          <div className="flex justify-center py-24">
            <div className="h-8 w-8 rounded-full border-2 border-line border-t-accent animate-spin" />
          </div>
        ) : error ? (
          <div role="alert" className="rounded-2xl border border-red-500/40 bg-card p-5 text-sm">
            {error}
          </div>
        ) : (
          <div key={tab}>
            {tab === 'inicio' && <Dashboard go={go} />}
            {tab === 'registrar' && <Register initialDate={editDate} onConsumed={() => setEditDate(null)} />}
            {tab === 'stats' && <Stats go={go} />}
            {tab === 'historial' && (
              <History
                go={go}
                onEdit={(d) => {
                  setEditDate(d)
                  go('registrar')
                }}
              />
            )}
            {tab === 'config' && <Settings />}
          </div>
        )}
      </main>

      <BottomNav tab={tab} onChange={go} />
    </div>
  )
}
