import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react'

const ToastCtx = createContext<(msg: string) => void>(() => {})
export const useToast = () => useContext(ToastCtx)

export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState<string | null>(null)
  const timer = useRef<number | undefined>(undefined)

  const show = useCallback((m: string) => {
    setMsg(m)
    window.clearTimeout(timer.current)
    timer.current = window.setTimeout(() => setMsg(null), 2400)
  }, [])

  return (
    <ToastCtx.Provider value={show}>
      {children}
      {msg && (
        <div
          role="status"
          className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 pointer-events-none"
        >
          <div className="animate-fade-up rounded-full bg-card2 border border-line px-4 py-2.5 text-sm shadow-lg">
            {msg}
          </div>
        </div>
      )}
    </ToastCtx.Provider>
  )
}
