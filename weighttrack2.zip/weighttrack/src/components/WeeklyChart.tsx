import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useWeight } from '../store/WeightContext'
import { addDays, formatShort, formatWeekRange, todayISO, weekStartOf } from '../lib/dates'
import { groupByWeek } from '../lib/stats'
import { fmtNum, kgToUnit } from '../lib/units'
import { Card, EmptyState, SectionTitle, Segmented } from './ui'
import { ChartIcon } from './Icons'

const ranges = [
  { value: 8, label: '8 sem.' },
  { value: 26, label: '26 sem.' },
  { value: 0, label: 'Todo' },
]

const PARTIAL_BELOW = 3 // semanas con menos de 3 registros se muestran atenuadas

interface Row {
  start: string
  label: string
  avg: number | null
  count: number
  current: boolean
}

function Tip({ active, payload, unit }: any) {
  if (!active || !payload?.length) return null
  const r = payload[0].payload as Row
  return (
    <div className="rounded-xl bg-card2 border border-line px-3 py-2 text-sm shadow-lg">
      <p className="text-muted text-xs">Semana {formatWeekRange(r.start)}</p>
      {r.avg == null ? (
        <p className="font-semibold">Sin registros</p>
      ) : (
        <>
          <p className="font-semibold tabular-nums">
            {fmtNum(r.avg, 2, 2)} {unit}
          </p>
          <p className="text-xs text-muted">
            {r.count} {r.count === 1 ? 'registro' : 'registros'} de 7 días
          </p>
        </>
      )}
    </div>
  )
}

export default function WeeklyChart() {
  const { entries, settings } = useWeight()
  const u = settings.unit
  const ws = settings.weekStart
  const [range, setRange] = useState<number>(8)
  const today = todayISO()

  const data = useMemo<Row[]>(() => {
    if (!entries.length) return []
    const weeks = groupByWeek(entries, ws)
    const byStart = new Map(weeks.map((w) => [w.start, w]))
    const cur = weekStartOf(today, ws)
    let first = weeks[0].start
    if (range > 0) {
      const lim = addDays(cur, -7 * (range - 1))
      if (first < lim) first = lim
    }
    const rows: Row[] = []
    // Las semanas sin registros quedan como hueco (null): no se inventa ningún valor.
    for (let s = first; s <= cur; s = addDays(s, 7)) {
      const w = byStart.get(s)
      rows.push({
        start: s,
        label: formatShort(s),
        avg: w ? kgToUnit(w.avg, u) : null,
        count: w ? w.count : 0,
        current: s === cur,
      })
    }
    return rows
  }, [entries, ws, u, range, today])

  const hasData = data.some((r) => r.avg != null)

  return (
    <Card>
      <SectionTitle>Promedios semanales</SectionTitle>
      <Segmented value={range} options={ranges} onChange={setRange} />
      {!hasData ? (
        <div className="mt-4">
          <EmptyState
            icon={<ChartIcon />}
            title="Sin promedios para mostrar"
            text="Cuando registres tu peso vas a ver cómo evoluciona el promedio de cada semana."
          />
        </div>
      ) : (
        <>
          <div className="mt-4 h-60 -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="#222831" vertical={false} />
                <XAxis
                  dataKey="label"
                  stroke="#4b5563"
                  tick={{ fill: '#8b95a3', fontSize: 11 }}
                  tickLine={false}
                  interval="preserveStartEnd"
                  minTickGap={14}
                />
                <YAxis
                  domain={[(m: number) => Math.floor(m - 1), (m: number) => Math.ceil(m + 1)]}
                  stroke="#4b5563"
                  tick={{ fill: '#8b95a3', fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                  width={44}
                  tickFormatter={(v: number) => fmtNum(v, 0, 1)}
                />
                <Tooltip content={<Tip unit={u} />} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
                <Bar dataKey="avg" radius={[6, 6, 0, 0]} animationDuration={500}>
                  {data.map((r) => (
                    <Cell
                      key={r.start}
                      fill={r.current ? '#60a5fa' : '#6ee7a8'}
                      fillOpacity={r.count > 0 && r.count < PARTIAL_BELOW ? 0.45 : 1}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted">
            <Legend color="#60a5fa" label="Semana en curso" />
            <Legend color="#6ee7a8" label="Semanas anteriores" />
            <Legend color="#6ee7a8" faded label={`Menos de ${PARTIAL_BELOW} registros`} />
          </div>
          <p className="mt-2 text-xs text-muted">
            El eje no empieza en cero para que se noten las diferencias. Los huecos son semanas sin registros.
          </p>
        </>
      )}
    </Card>
  )
}

function Legend({ color, label, faded }: { color: string; label: string; faded?: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        className="h-2.5 w-2.5 rounded-sm"
        style={{ background: color, opacity: faded ? 0.45 : 1 }}
      />
      {label}
    </span>
  )
}
