import type { ButtonHTMLAttributes, ReactNode } from 'react'

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-2xl bg-card border border-line/70 p-4 ${className}`}>{children}</div>
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-sm font-semibold tracking-wide text-muted uppercase">{children}</h2>
      {right}
    </div>
  )
}

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost'
const variants: Record<Variant, string> = {
  primary: 'bg-accent text-black hover:brightness-110',
  secondary: 'bg-card2 text-white border border-line hover:bg-line/60',
  danger: 'bg-red-500/90 text-white hover:bg-red-500',
  ghost: 'text-muted hover:text-white hover:bg-card2',
}

export function Button({
  variant = 'secondary',
  className = '',
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      {...rest}
      className={`h-12 px-4 rounded-xl font-semibold text-[15px] transition active:scale-[.98] disabled:opacity-40 disabled:pointer-events-none inline-flex items-center justify-center gap-2 ${variants[variant]} ${className}`}
    />
  )
}

export function IconButton({
  label,
  className = '',
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      {...rest}
      aria-label={label}
      title={label}
      className={`h-10 w-10 rounded-xl inline-flex items-center justify-center text-muted hover:text-white hover:bg-card2 transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none ${className}`}
    />
  )
}

export function Segmented<T extends string | number>({
  value,
  options,
  onChange,
}: {
  value: T
  options: { value: T; label: string }[]
  onChange: (v: T) => void
}) {
  return (
    <div className="flex rounded-xl bg-card2 p-1 border border-line/70" role="tablist">
      {options.map((o) => (
        <button
          key={String(o.value)}
          role="tab"
          aria-selected={o.value === value}
          onClick={() => onChange(o.value)}
          className={`flex-1 h-9 rounded-lg text-sm font-medium transition ${
            o.value === value ? 'bg-accent text-black' : 'text-muted hover:text-white'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

export function Stat({
  label,
  value,
  sub,
  className = '',
}: {
  label: string
  value: ReactNode
  sub?: ReactNode
  className?: string
}) {
  return (
    <Card className={className}>
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1.5 text-xl font-semibold tabular-nums">{value}</p>
      {sub && <p className="mt-1 text-xs text-muted">{sub}</p>}
    </Card>
  )
}

export function EmptyState({
  icon,
  title,
  text,
  children,
}: {
  icon: ReactNode
  title: string
  text: string
  children?: ReactNode
}) {
  return (
    <div className="animate-fade-up flex flex-col items-center text-center rounded-2xl border border-dashed border-line px-6 py-10">
      <div className="h-14 w-14 rounded-2xl bg-card2 text-accent flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-1.5 text-sm text-muted max-w-xs">{text}</p>
      {children && <div className="mt-5 flex flex-col gap-2 w-full max-w-xs">{children}</div>}
    </div>
  )
}

export function PageTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
      {subtitle && <p className="text-sm text-muted mt-0.5">{subtitle}</p>}
    </div>
  )
}

export function DemoBadge() {
  return (
    <span className="ml-2 rounded-md bg-blue/15 text-blue text-[10px] font-bold tracking-wider px-1.5 py-0.5 align-middle">
      DEMO
    </span>
  )
}
