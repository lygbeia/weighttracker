import type { SVGProps } from 'react'

type P = SVGProps<SVGSVGElement>
const Svg = (p: P) => (
  <svg
    width="22"
    height="22"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    {...p}
  />
)

export const HomeIcon = (p: P) => (
  <Svg {...p}>
    <path d="M3 11.5 12 4l9 7.5" />
    <path d="M5.5 10v9.5h13V10" />
  </Svg>
)
export const PlusIcon = (p: P) => (
  <Svg {...p}>
    <path d="M12 5v14M5 12h14" />
  </Svg>
)
export const ChartIcon = (p: P) => (
  <Svg {...p}>
    <path d="M4 19V5" />
    <path d="M4 19h16" />
    <path d="m7.5 14 3.5-4 3 3 4.5-6" />
  </Svg>
)
export const ListIcon = (p: P) => (
  <Svg {...p}>
    <path d="M8 6h12M8 12h12M8 18h12" />
    <path d="M4 6h.01M4 12h.01M4 18h.01" />
  </Svg>
)
export const SlidersIcon = (p: P) => (
  <Svg {...p}>
    <path d="M4 7h10M18 7h2M4 17h2M10 17h10" />
    <circle cx="16" cy="7" r="2" />
    <circle cx="8" cy="17" r="2" />
  </Svg>
)
export const TrashIcon = (p: P) => (
  <Svg {...p}>
    <path d="M4 7h16M10 11v6M14 11v6" />
    <path d="M6 7l1 12h10l1-12M9 7V4h6v3" />
  </Svg>
)
export const PencilIcon = (p: P) => (
  <Svg {...p}>
    <path d="M4 20h4L19 9l-4-4L4 16v4Z" />
    <path d="m13.5 6.5 4 4" />
  </Svg>
)
export const ChevLeftIcon = (p: P) => (
  <Svg {...p}>
    <path d="m15 6-6 6 6 6" />
  </Svg>
)
export const ChevRightIcon = (p: P) => (
  <Svg {...p}>
    <path d="m9 6 6 6-6 6" />
  </Svg>
)
export const DownloadIcon = (p: P) => (
  <Svg {...p}>
    <path d="M12 4v11m0 0-4-4m4 4 4-4" />
    <path d="M5 19h14" />
  </Svg>
)
export const UploadIcon = (p: P) => (
  <Svg {...p}>
    <path d="M12 15V4m0 0L8 8m4-4 4 4" />
    <path d="M5 19h14" />
  </Svg>
)
export const ArrowUpIcon = (p: P) => (
  <Svg {...p}>
    <path d="M12 19V5m0 0-6 6m6-6 6 6" />
  </Svg>
)
export const ArrowDownIcon = (p: P) => (
  <Svg {...p}>
    <path d="M12 5v14m0 0-6-6m6 6 6-6" />
  </Svg>
)
export const EqualIcon = (p: P) => (
  <Svg {...p}>
    <path d="M5 9h14M5 15h14" />
  </Svg>
)
export const ShieldIcon = (p: P) => (
  <Svg {...p}>
    <path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.500 7-10V6l-7-3Z" />
    <path d="m9 12 2 2 4-4" />
  </Svg>
)
export const ScaleIcon = (p: P) => (
  <Svg {...p}>
    <rect x="4" y="4" width="16" height="16" rx="4" />
    <path d="M8.500 9a5 5 0 0 1 7 0" />
    <path d="m12 11 1.500-2" />
  </Svg>
)
