import { useEffect, useMemo, useState } from 'react'
import { useWeight } from '../store/WeightContext'
import { addDays, formatRow, formatWeekRange, todayISO, weekStartOf } from '../lib/dates'
import { summarizeWeek, trendOf } from '../lib/stats'
import { fmtAvg, fmtDelta, fmtWeight } from '../lib/units'
import { Card, EmptyState, IconButton, SectionTitle } from './ui'
import { ArrowDownIcon, ArrowUpIcon, ChevLeftIcon, ChevRightIcon, EqualIcon, ListIcon } from './Icons'

export default function WeekExplorer() {
  const { entries, settings } = useWeight()
  const u = settings.unit
  const ws = settings.weekStart
  const today = todayISO()
  const curStart = weekStartOf(today, ws)
  const [start, setStart] = useState(curStart)

  // Si cambia el primer día de la semana, vuelve a la semana actual.
  useEffect(() => setStart(weekStartOf(todayISO(), ws)), [ws])

  const firstStart = entries.length ? weekStartOf(entries[0].date, ws) : curStart
  const week = useMemo(() => summarizeWeek(entries, start), [entries, start])
  const prev = useMemo(() => summarizeWeek(entries, addDays(start, -7)), [entries, start])
  const diff = week && prev ? week.avg - prev.avg : null
  const trend = diff == null ? null : trendOf(diff)

  return (
    <Card>
      <SectionTitle>Consultar semanas</SectionTitle>
      <div className="flex items-center justify-between">
        <IconButton label="Semana anterior" disabled={start <= firstStart} onClick={() => setStart(addDays(start, -7))}>
          <ChevLeftIcon />
        </IconButton>
        <div className="text-center">
          <p className="font-semibold">{formatWeekRange(start)}</p>
          <p className="text-xs text-muted">{start === curStart ? 'Semana en curso' : 'Semana pasada'}</p>
        </div>
        <IconButton label="Semana siguiente" disabled={start >= curStart} onClick={() => setStart(addDays(start, 7))}>
          <ChevRightIcon />
        </IconButton>
      </div>

      {!week ? (
        <div className="mt-4">
          <EmptyState
            icon={<ListIcon />}
            title="Sin registros esta semana"
            text="No hay pesos cargados en estas fechas, por eso no se muestra ningún promedio."
          />
        </div>
      ) : (
        <div className="mt-4 animate-fade-up">
          <div className="rounded-xl bg-card2 p-4 text-center">
            <p className="text-xs text-muted">Promedio semanal</p>
            <p className="text-3xl font-bold tabular-nums mt-1">{fmtAvg(week.avg, u)}</p>
            <p className="text-xs text-muted mt-1">
              {week.count} {week.count === 1 ? 'día registrado' : 'días registrados'} de 7
            </p>
            {diff != null && trend && (
              <p className="mt-2 inline-flex items-center gap-1 text-sm text-blue">
                {trend === 'up' ? <ArrowUpIcon width={16} height={16} /> : trend === 'down' ? <ArrowDownIcon width={16} height={16} /> : <EqualIcon width={16} height={16} />}
                {fmtDelta(diff, u)} vs semana anterior
              </p>
            )}
            {diff == null && <p className="mt-2 text-xs text-muted">Sin semana anterior con registros para comparar.</p>}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-xl bg-card2 py-2">
              <p className="text-[11px] text-muted">Mínimo</p>
              <p className="text-sm font-semibold tabular-nums">{fmtWeight(week.min, u)}</p>
            </div>
            <div className="rounded-xl bg-card2 py-2">
              <p className="text-[11px] text-muted">Máximo</p>
              <p className="text-sm font-semibold tabular-nums">{fmtWeight(week.max, u)}</p>
            </div>
          </div>
          <ul className="mt-3 divide-y divide-line/60">
            {week.entries.map((e) => (
              <li key={e.date} className="flex justify-between py-2 text-sm">
                <span className="text-muted">{formatRow(e.date)}</span>
                <span className="font-medium tabular-nums">{fmtWeight(e.kg, u)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {start !== curStart && (
        <button className="mt-3 w-full text-sm text-accent py-2" onClick={() => setStart(curStart)}>
          Volver a la semana actual
        </button>
      )}
    </Card>
  )
}
