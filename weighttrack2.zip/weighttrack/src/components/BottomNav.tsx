import type { ComponentType, SVGProps } from 'react'
import type { Tab } from '../types'
import { ChartIcon, HomeIcon, ListIcon, PlusIcon } from './Icons'

const items: {
  id: Tab
  label: string
  Icon: ComponentType<SVGProps<SVGSVGElement>>
  primary?: boolean
}[] = [
  { id: 'inicio', label: 'Inicio', Icon: HomeIcon },
  { id: 'registrar', label: 'Registrar', Icon: PlusIcon, primary: true },
  { id: 'stats', label: 'Estadísticas', Icon: ChartIcon },
  { id: 'historial', label: 'Historial', Icon: ListIcon },
]

export default function BottomNav({ tab, onChange }: { tab: Tab; onChange: (t: Tab) => void }) {
  return (
    <nav
      aria-label="Navegación principal"
      className="fixed bottom-0 inset-x-0 z-30 border-t border-line/70 bg-bg/85 backdrop-blur-md"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="mx-auto max-w-3xl grid grid-cols-4 px-2">
        {items.map(({ id, label, Icon, primary }) => {
          const active = tab === id
          return (
            <button
              key={id}
              onClick={() => onChange(id)}
              aria-current={active ? 'page' : undefined}
              className="flex flex-col items-center justify-center gap-1 py-2 text-[11px] font-medium transition active:scale-95"
            >
              {primary ? (
                <span
                  className={`h-9 w-14 rounded-2xl bg-accent text-black flex items-center justify-center shadow-[0_0_20px_-4px_rgba(110,231,168,.55)] transition ${
                    active ? 'brightness-110' : ''
                  }`}
                >
                  <Icon />
                </span>
              ) : (
                <span className={`h-9 flex items-center ${active ? 'text-accent' : 'text-muted'}`}>
                  <Icon />
                </span>
              )}
              <span className={active ? 'text-white' : 'text-muted'}>{label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
