import { useMemo, useState } from 'react'
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useWeight } from '../store/WeightContext'
import { addDays, dateToMs, diffDays, formatLong, formatShort, todayISO } from '../lib/dates'
import { fmtNum, kgToUnit } from '../lib/units'
import { Card, EmptyState, SectionTitle, Segmented } from './ui'
import { ChartIcon } from './Icons'

type Period = 7 | 30 | 90 | 0
const periods: { value: Period; label: string }[] = [
  { value: 7, label: '7 días' },
  { value: 30, label: '30 días' },
  { value: 90, label: '90 días' },
  { value: 0, label: 'Todo' },
]

function Tip({ active, payload, unit }: any) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload as { date: string; v: number }
  return (
    <div className="rounded-xl bg-card2 border border-line px-3 py-2 text-sm shadow-lg">
      <p className="text-muted text-xs">{formatLong(p.date)}</p>
      <p className="font-semibold tabular-nums">
        {fmtNum(p.v, 1, 2)} {unit}
      </p>
    </div>
  )
}

export default function EvolutionChart() {
  const { entries, settings } = useWeight()
  const u = settings.unit
  const [period, setPeriod] = useState<Period>(30)
  const today = todayISO()

  const view = useMemo(() => {
    if (!entries.length) return null
    let start: string
    let end: string
    if (period === 0) {
      start = entries[0].date
      end = entries[entries.length - 1].date
    } else {
      end = today
      start = addDays(today, -(period - 1))
    }
    const pts = entries
      .filter((e) => e.date >= start && e.date <= end)
      .map((e) => ({ t: dateToMs(e.date), date: e.date, v: kgToUnit(e.kg, u) }))
    if (start === end) {
      start = addDays(start, -1)
      end = addDays(end, 1)
    }
    const span = diffDays(end, start)
    const step = Math.max(1, Math.ceil(span / 5))
    const ticks: number[] = []
    for (let d = 0; d <= span; d += step) ticks.push(dateToMs(addDays(start, d)))
    const vals = pts.map((p) => p.v)
    return {
      pts,
      ticks,
      domain: [dateToMs(start), dateToMs(end)] as [number, number],
      min: vals.length ? Math.min(...vals) : 0,
      max: vals.length ? Math.max(...vals) : 0,
    }
  }, [entries, period, u, today])

  const fmtTick = (t: number) => {
    const d = new Date(t)
    const iso = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(
      d.getUTCDate(),
    ).padStart(2, '0')}`
    return formatShort(iso)
  }

  return (
    <Card>
      <SectionTitle>Evolución del peso</SectionTitle>
      <Segmented value={period} options={periods} onChange={setPeriod} />
      {!view || view.pts.length === 0 ? (
        <div className="mt-4">
          <EmptyState
            icon={<ChartIcon />}
            title="Sin registros en este período"
            text="Probá con otro período o registrá tu peso para ver la evolución."
          />
        </div>
      ) : (
        <>
          <div className="mt-4 h-60 -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={view.pts} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="#222831" vertical={false} />
                <XAxis
                  dataKey="t"
                  type="number"
                  scale="time"
                  domain={view.domain}
                  ticks={view.ticks}
                  tickFormatter={fmtTick}
                  stroke="#4b5563"
                  tick={{ fill: '#8b95a3', fontSize: 11 }}
                  tickLine={false}
                />
                <YAxis
                  domain={[(m: number) => Math.floor(m - 0.5), (m: number) => Math.ceil(m + 0.5)]}
                  stroke="#4b5563"
                  tick={{ fill: '#8b95a3', fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                  width={44}
                  tickFormatter={(v: number) => fmtNum(v, 0, 1)}
                />
                <Tooltip
                  content={<Tip unit={u} />}
                  cursor={{ stroke: '#3a424d', strokeDasharray: '3 3' }}
                />
                <Line
                  type="linear"
                  dataKey="v"
                  stroke="#6ee7a8"
                  strokeWidth={2.5}
                  dot={view.pts.length <= 45 ? { r: 3, fill: '#6ee7a8', strokeWidth: 0 } : false}
                  activeDot={{ r: 6, fill: '#6ee7a8', stroke: '#0b0d10', strokeWidth: 2 }}
                  isAnimationActive
                  animationDuration={500}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <Mini label="Registros" value={String(view.pts.length)} />
            <Mini label="Mínimo" value={`${fmtNum(view.min, 1, 2)} ${u}`} />
            <Mini label="Máximo" value={`${fmtNum(view.max, 1, 2)} ${u}`} />
          </div>
          <p className="mt-3 text-xs text-muted">
            Tocá un punto para ver el peso de ese día. La línea une solo días con registro real.
          </p>
        </>
      )}
    </Card>
  )
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card2 py-2">
      <p className="text-[11px] text-muted">{label}</p>
      <p className="text-sm font-semibold tabular-nums">{value}</p>
    </div>
  )
}
