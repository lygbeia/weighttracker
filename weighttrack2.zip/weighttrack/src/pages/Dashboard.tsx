import { useMemo } from 'react'
import type { Tab } from '../types'
import { useWeight } from '../store/WeightContext'
import { useToast } from '../components/Toast'
import { Button, Card, EmptyState, PageTitle, Stat } from '../components/ui'
import { ArrowDownIcon, ArrowUpIcon, EqualIcon, ScaleIcon } from '../components/Icons'
import { addDays, formatLong, relativeDay, todayISO, weekStartOf } from '../lib/dates'
import { entriesBetween, summarizeWeek, trendOf } from '../lib/stats'
import { fmtAbs, fmtAvg, fmtDelta, fmtWeight } from '../lib/units'

export default function Dashboard({ go }: { go: (t: Tab) => void }) {
  const { entries, settings, hasDemo, loadDemo, removeDemo } = useWeight()
  const toast = useToast()
  const u = settings.unit
  const today = todayISO()
  const curStart = weekStartOf(today, settings.weekStart)

  const d = useMemo(() => {
    const cur = summarizeWeek(entries, curStart)
    const prev = summarizeWeek(entries, addDays(curStart, -7))
    const last7 = entriesBetween(entries, addDays(today, -6), today)
    const kgs = last7.map((e) => e.kg)
    return {
      cur,
      prev,
      diff: cur && prev ? cur.avg - prev.avg : null,
      min: kgs.length ? Math.min(...kgs) : null,
      max: kgs.length ? Math.max(...kgs) : null,
      latest: entries[entries.length - 1],
      before: entries[entries.length - 2],
    }
  }, [entries, curStart, today])

  if (!entries.length) {
    return (
      <div className="animate-fade-up">
        <PageTitle title="Inicio" subtitle="Tu seguimiento de peso, privado y en tu dispositivo" />
        <EmptyState
          icon={<ScaleIcon />}
          title="Todavía no hay registros"
          text="Registrá tu peso de hoy para empezar a ver promedios semanales y tu evolución."
        >
          <Button variant="primary" onClick={() => go('registrar')}>
            Registrar mi primer peso
          </Button>
          <Button
            onClick={async () => {
              await loadDemo()
              toast('Datos de demostración cargados')
            }}
          >
            Probar con datos de demostración
          </Button>
        </EmptyState>
      </div>
    )
  }

  const trend = d.diff == null ? null : trendOf(d.diff)
  let message: string
  if (!d.cur) message = 'Todavía no registraste tu peso esta semana.'
  else if (!d.prev || d.diff == null) message = 'Aún no hay una semana anterior con registros para comparar.'
  else if (trend === 'stable') message = `Tu promedio semanal se mantuvo estable (${fmtDelta(d.diff, u)}).`
  else if (trend === 'up') message = `Tu promedio semanal aumentó ${fmtAbs(d.diff, u)} respecto de la semana anterior.`
  else message = `Tu promedio semanal disminuyó ${fmtAbs(d.diff, u)} respecto de la semana anterior.`

  const TrendIcon = trend === 'up' ? ArrowUpIcon : trend === 'down' ? ArrowDownIcon : EqualIcon
  const lastDelta = d.before ? d.latest.kg - d.before.kg : null

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle title="Inicio" subtitle={formatLong(today)} />

      {hasDemo && (
        <Card className="flex items-center justify-between gap-3 !border-blue/40">
          <p className="text-sm">
            <span className="font-semibold text-blue">Datos de demostración.</span> Son ficticios.
          </p>
          <Button
            className="!h-9 !px-3 !text-sm shrink-0"
            onClick={async () => {
              await removeDemo()
              toast('Datos de demostración eliminados')
            }}
          >
            Eliminar
          </Button>
        </Card>
      )}

      <Card className="!p-5">
        <p className="text-xs text-muted">Último registro</p>
        <p className="mt-1 text-4xl font-bold tabular-nums tracking-tight">{fmtWeight(d.latest.kg, u)}</p>
        <p className="mt-1 text-sm text-muted">
          {relativeDay(d.latest.date, today)}
          {lastDelta != null && <> · {fmtDelta(lastDelta, u)} vs registro anterior</>}
        </p>
      </Card>

      <Card className="flex items-start gap-3">
        <span className="mt-0.5 h-9 w-9 shrink-0 rounded-xl bg-blue/15 text-blue flex items-center justify-center">
          <TrendIcon width={18} height={18} />
        </span>
        <div>
          <p className="font-medium leading-snug">{message}</p>
          <p className="mt-1 text-xs text-muted">
            El peso diario fluctúa por agua, comidas y sal: no lo tomes como un cambio real de composición corporal.
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Stat
          label="Promedio semana actual"
          value={d.cur ? fmtAvg(d.cur.avg, u) : '—'}
          sub={d.cur ? `${d.cur.count} ${d.cur.count === 1 ? 'registro' : 'registros'}` : 'Sin registros'}
        />
        <Stat
          label="Promedio semana anterior"
          value={d.prev ? fmtAvg(d.prev.avg, u) : '—'}
          sub={d.prev ? `${d.prev.count} ${d.prev.count === 1 ? 'registro' : 'registros'}` : 'Sin registros'}
        />
        <Stat
          label="Diferencia de promedios"
          value={d.diff != null ? fmtDelta(d.diff, u) : '—'}
          sub={d.diff != null ? 'Actual − anterior' : 'Faltan datos para comparar'}
        />
        <Stat
          label="Registros esta semana"
          value={`${d.cur?.count ?? 0} de 7`}
          sub="Días con peso cargado"
        />
        <Stat label="Máximo (7 días)" value={d.max != null ? fmtWeight(d.max, u) : '—'} />
        <Stat label="Mínimo (7 días)" value={d.min != null ? fmtWeight(d.min, u) : '—'} />
      </div>

      <Button variant="primary" className="w-full" onClick={() => go('registrar')}>
        Registrar peso
      </Button>
    </div>
  )
}
