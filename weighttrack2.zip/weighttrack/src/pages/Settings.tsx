import { useRef, useState } from 'react'
import { useWeight } from '../store/WeightContext'
import { useToast } from '../components/Toast'
import ConfirmDialog from '../components/ConfirmDialog'
import { Button, Card, PageTitle, SectionTitle, Segmented } from '../components/ui'
import { DownloadIcon, ShieldIcon, UploadIcon } from '../components/Icons'
import { downloadFile, entriesToCSV, makeBackup, parseBackup, parseCSV, type ParsedCSV } from '../lib/csv'
import { todayISO } from '../lib/dates'
import { useInstall } from '../lib/useInstall'
import type { Settings as SettingsT, Unit, WeekStart, WeightEntry } from '../types'

export default function Settings() {
  const { entries, settings, hasDemo, updateSettings, importEntries, replaceAll, clearAll, loadDemo, removeDemo } =
    useWeight()
  const toast = useToast()
  const csvRef = useRef<HTMLInputElement>(null)
  const jsonRef = useRef<HTMLInputElement>(null)
  const [pendingCSV, setPendingCSV] = useState<ParsedCSV | null>(null)
  const [pendingBackup, setPendingBackup] = useState<{ entries: WeightEntry[]; settings: SettingsT | null } | null>(null)
  const [confirmClear, setConfirmClear] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const stamp = todayISO()
  const { canInstall, installed, install } = useInstall()

  const pickFile = async (file: File | undefined, kind: 'csv' | 'json') => {
    setMsg(null)
    if (!file) return
    try {
      const text = await file.text()
      if (kind === 'csv') {
        const parsed = parseCSV(text)
        if (!parsed.rows.length) {
          setMsg(
            parsed.errors.length
              ? `No se encontraron registros válidos. ${parsed.errors.join(' · ')}`
              : 'El archivo no tiene registros para importar.',
          )
          return
        }
        setPendingCSV(parsed)
      } else {
        setPendingBackup(parseBackup(text))
      }
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'No se pudo leer el archivo.')
    }
  }

  const real = entries.filter((e) => !e.demo).length

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle title="Configuración" />

      {(installed || canInstall) && (
        <Card className="space-y-3">
          <SectionTitle>Aplicación</SectionTitle>
          {installed ? (
            <p className="text-sm text-muted">WeightTrack está instalada y funciona sin conexión.</p>
          ) : (
            <>
              <p className="text-sm text-muted">
                Instalala en tu pantalla de inicio para abrirla como una app, sin barra del navegador y sin conexión.
              </p>
              <Button variant="primary" onClick={install}>
                Instalar WeightTrack
              </Button>
            </>
          )}
        </Card>
      )}

      <Card className="space-y-4">
        <div>
          <SectionTitle>Unidad de peso</SectionTitle>
          <Segmented<Unit>
            value={settings.unit}
            onChange={(unit) => updateSettings({ unit })}
            options={[
              { value: 'kg', label: 'Kilogramos (kg)' },
              { value: 'lb', label: 'Libras (lb)' },
            ]}
          />
          <p className="mt-2 text-xs text-muted">Los datos se guardan en kg; cambiar la unidad solo cambia cómo se muestran.</p>
        </div>
        <div>
          <SectionTitle>La semana empieza el</SectionTitle>
          <Segmented<WeekStart>
            value={settings.weekStart}
            onChange={(weekStart) => updateSettings({ weekStart })}
            options={[
              { value: 1, label: 'Lunes' },
              { value: 0, label: 'Domingo' },
              { value: 6, label: 'Sábado' },
            ]}
          />
          <p className="mt-2 text-xs text-muted">Los promedios se recalculan al instante según el día elegido.</p>
        </div>
      </Card>

      <Card className="space-y-3">
        <SectionTitle>Datos</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          <Button
            disabled={!entries.length}
            onClick={() => downloadFile(`weighttrack-${stamp}.csv`, 'text/csv;charset=utf-8', entriesToCSV(entries))}
          >
            <DownloadIcon width={18} height={18} /> Exportar CSV
          </Button>
          <Button onClick={() => csvRef.current?.click()}>
            <UploadIcon width={18} height={18} /> Importar CSV
          </Button>
          <Button
            disabled={!entries.length}
            onClick={() =>
              downloadFile(`weighttrack-backup-${stamp}.json`, 'application/json', makeBackup(entries, settings))
            }
          >
            <DownloadIcon width={18} height={18} /> Copia de seguridad
          </Button>
          <Button onClick={() => jsonRef.current?.click()}>
            <UploadIcon width={18} height={18} /> Restaurar copia
          </Button>
        </div>
        <input
          ref={csvRef}
          type="file"
          accept=".csv,text/csv,text/plain"
          hidden
          onChange={(e) => {
            pickFile(e.target.files?.[0], 'csv')
            e.target.value = ''
          }}
        />
        <input
          ref={jsonRef}
          type="file"
          accept=".json,application/json"
          hidden
          onChange={(e) => {
            pickFile(e.target.files?.[0], 'json')
            e.target.value = ''
          }}
        />
        {msg && (
          <p role="alert" className="text-sm text-red-400">
            {msg}
          </p>
        )}
        <p className="text-xs text-muted">
          El CSV usa «;» como separador y coma decimal (se abre bien en Excel y Sheets). Al importar, las fechas que ya existen se actualizan. La copia de seguridad incluye también tus ajustes.
        </p>
      </Card>

      <Card className="space-y-3">
        <SectionTitle>Datos de demostración</SectionTitle>
        <p className="text-xs text-muted">
          Registros ficticios de ~9 semanas, marcados con «DEMO». Nunca pisan tus registros reales y se eliminan con un toque.
        </p>
        {hasDemo ? (
          <Button
            onClick={async () => {
              await removeDemo()
              toast('Datos de demostración eliminados')
            }}
          >
            Eliminar datos de demostración
          </Button>
        ) : (
          <Button
            onClick={async () => {
              await loadDemo()
              toast('Datos de demostración cargados')
            }}
          >
            Cargar datos de demostración
          </Button>
        )}
      </Card>

      <Card className="space-y-3">
        <SectionTitle>Zona de peligro</SectionTitle>
        <Button variant="danger" disabled={!entries.length} onClick={() => setConfirmClear(true)}>
          Eliminar todo el historial
        </Button>
      </Card>

      <Card className="flex gap-3">
        <span className="h-9 w-9 shrink-0 rounded-xl bg-accent/15 text-accent flex items-center justify-center">
          <ShieldIcon width={18} height={18} />
        </span>
        <div className="text-sm">
          <p className="font-medium">Privacidad total</p>
          <p className="text-xs text-muted mt-1">
            Tus datos viven solo en este navegador (IndexedDB). No hay cuentas, servidores ni seguimiento. Si borrás los datos del navegador o cambiás de dispositivo, se pierden: exportá una copia de vez en cuando.
          </p>
        </div>
      </Card>

      <ConfirmDialog
        open={pendingCSV != null}
        title="Importar registros"
        message={
          pendingCSV
            ? `Se importarán ${pendingCSV.rows.length} registros. Los de fechas que ya existen se actualizarán.` +
              (pendingCSV.skipped ? `\nSe omitieron ${pendingCSV.skipped} filas inválidas.` : '')
            : ''
        }
        confirmLabel="Importar"
        onCancel={() => setPendingCSV(null)}
        onConfirm={async () => {
          const p = pendingCSV
          setPendingCSV(null)
          if (p) {
            await importEntries(p.rows)
            toast(`${p.rows.length} registros importados`)
          }
        }}
      />
      <ConfirmDialog
        open={pendingBackup != null}
        danger
        title="Restaurar copia de seguridad"
        message={
          pendingBackup
            ? `Se reemplazarán TODOS tus registros actuales por los ${pendingBackup.entries.length} de la copia.`
            : ''
        }
        confirmLabel="Restaurar"
        onCancel={() => setPendingBackup(null)}
        onConfirm={async () => {
          const p = pendingBackup
          setPendingBackup(null)
          if (p) {
            await replaceAll(p.entries, p.settings)
            toast('Copia restaurada')
          }
        }}
      />
      <ConfirmDialog
        open={confirmClear}
        danger
        title="¿Eliminar todo el historial?"
        message={`Se borrarán los ${entries.length} registros${real < entries.length ? ' (incluidos los de demostración)' : ''}. Esta acción no se puede deshacer. Si no tenés una copia, exportala antes.`}
        confirmLabel="Eliminar todo"
        onCancel={() => setConfirmClear(false)}
        onConfirm={async () => {
          setConfirmClear(false)
          await clearAll()
          toast('Historial eliminado')
        }}
      />
    </div>
  )
}
