import { useMemo, useState } from 'react'
import type { Tab } from '../types'
import { useWeight } from '../store/WeightContext'
import { useToast } from '../components/Toast'
import ConfirmDialog from '../components/ConfirmDialog'
import { Button, Card, DemoBadge, EmptyState, IconButton, PageTitle } from '../components/ui'
import { ListIcon, PencilIcon, TrashIcon } from '../components/Icons'
import { formatLong, formatRow, weekStartOf } from '../lib/dates'
import { groupByWeek } from '../lib/stats'
import { fmtAvg, fmtDelta, fmtWeight } from '../lib/units'

const PAGE = 60

interface Props {
  go: (t: Tab) => void
  onEdit: (date: string) => void
}

export default function History({ go, onEdit }: Props) {
  const { entries, settings, remove } = useWeight()
  const toast = useToast()
  const u = settings.unit
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [shown, setShown] = useState(PAGE)
  const [toDelete, setToDelete] = useState<string | null>(null)

  const weeks = useMemo(
    () => new Map(groupByWeek(entries, settings.weekStart).map((w) => [w.start, w])),
    [entries, settings.weekStart],
  )

  // La variación se calcula contra el registro inmediatamente anterior (sin tener en cuenta el filtro).
  const rows = useMemo(() => {
    const all = entries.map((e, i) => ({
      entry: e,
      delta: i > 0 ? e.kg - entries[i - 1].kg : null,
      week: weeks.get(weekStartOf(e.date, settings.weekStart)),
    }))
    return all
      .filter((r) => (!from || r.entry.date >= from) && (!to || r.entry.date <= to))
      .reverse()
  }, [entries, weeks, settings.weekStart, from, to])

  if (!entries.length) {
    return (
      <div className="animate-fade-up">
        <PageTitle title="Historial" />
        <EmptyState
          icon={<ListIcon />}
          title="Tu historial está vacío"
          text="Cada peso que registres va a aparecer acá, del más reciente al más antiguo."
        >
          <Button variant="primary" onClick={() => go('registrar')}>
            Registrar peso
          </Button>
        </EmptyState>
      </div>
    )
  }

  const filtered = from || to

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle title="Historial" subtitle={`${rows.length} ${rows.length === 1 ? 'registro' : 'registros'}`} />

      <Card className="!p-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="from" className="text-xs text-muted">
              Desde
            </label>
            <input
              id="from"
              type="date"
              value={from}
              max={to || undefined}
              onChange={(e) => {
                setFrom(e.target.value)
                setShown(PAGE)
              }}
              className="mt-1 w-full h-11 rounded-xl bg-card2 border border-line px-3 focus:outline-none focus:border-accent"
            />
          </div>
          <div>
            <label htmlFor="to" className="text-xs text-muted">
              Hasta
            </label>
            <input
              id="to"
              type="date"
              value={to}
              min={from || undefined}
              onChange={(e) => {
                setTo(e.target.value)
                setShown(PAGE)
              }}
              className="mt-1 w-full h-11 rounded-xl bg-card2 border border-line px-3 focus:outline-none focus:border-accent"
            />
          </div>
        </div>
        {filtered && (
          <button
            className="mt-2 text-sm text-accent"
            onClick={() => {
              setFrom('')
              setTo('')
            }}
          >
            Limpiar filtros
          </button>
        )}
      </Card>

      {rows.length === 0 ? (
        <EmptyState
          icon={<ListIcon />}
          title="Sin resultados"
          text="No hay registros en el rango de fechas elegido."
        />
      ) : (
        <ul className="space-y-2">
          {rows.slice(0, shown).map(({ entry, delta, week }) => (
            <li key={entry.date} className="rounded-2xl bg-card border border-line/70 p-3 pl-4 flex items-center gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline justify-between gap-2">
                  <p className="text-sm text-muted">
                    {formatRow(entry.date)}
                    {entry.demo && <DemoBadge />}
                  </p>
                  <p className="text-lg font-semibold tabular-nums">{fmtWeight(entry.kg, u)}</p>
                </div>
                <div className="mt-1 flex items-center justify-between gap-2 text-xs text-muted">
                  <span>{delta == null ? 'Primer registro' : `${fmtDelta(delta, u)} vs anterior`}</span>
                  {week && (
                    <span className="tabular-nums">
                      Prom. semana {fmtAvg(week.avg, u)} ({week.count})
                    </span>
                  )}
                </div>
              </div>
              <div className="flex">
                <IconButton label="Editar registro" onClick={() => onEdit(entry.date)}>
                  <PencilIcon width={18} height={18} />
                </IconButton>
                <IconButton label="Eliminar registro" onClick={() => setToDelete(entry.date)}>
                  <TrashIcon width={18} height={18} />
                </IconButton>
              </div>
            </li>
          ))}
        </ul>
      )}

      {rows.length > shown && (
        <Button className="w-full" onClick={() => setShown((s) => s + PAGE)}>
          Ver más
        </Button>
      )}

      <ConfirmDialog
        open={toDelete != null}
        danger
        title="¿Eliminar este registro?"
        message={toDelete ? `Se borrará el peso del ${formatLong(toDelete)}.` : ''}
        confirmLabel="Eliminar"
        onCancel={() => setToDelete(null)}
        onConfirm={async () => {
          const d = toDelete
          setToDelete(null)
          if (d) {
            await remove(d)
            toast('Registro eliminado')
          }
        }}
      />
    </div>
  )
}
