import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { useWeight } from '../store/WeightContext'
import { useToast } from '../components/Toast'
import ConfirmDialog from '../components/ConfirmDialog'
import { Button, Card, PageTitle, SectionTitle } from '../components/ui'
import { formatLong, formatRow, isValidISO, todayISO } from '../lib/dates'
import {
  MAX_KG,
  MIN_KG,
  fmtNum,
  fmtWeight,
  kgToUnit,
  parseWeightInput,
  roundKg,
  toInputString,
  unitToKg,
} from '../lib/units'

interface Props {
  initialDate?: string | null
  onConsumed: () => void
}

export default function Register({ initialDate, onConsumed }: Props) {
  const { entries, settings, upsert, remove } = useWeight()
  const toast = useToast()
  const u = settings.unit
  const today = todayISO()

  const [date, setDate] = useState(initialDate ?? today)
  const [text, setText] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [confirmDel, setConfirmDel] = useState(false)
  const [saving, setSaving] = useState(false)
  const hadRef = useRef(false)

  useEffect(() => {
    if (initialDate) onConsumed()
  }, [])

  const existing = useMemo(() => entries.find((e) => e.date === date), [entries, date])

  // Si ya hay registro en esa fecha se precarga (se va a actualizar, no a duplicar).
  useEffect(() => {
    if (existing) {
      setText(toInputString(kgToUnit(existing.kg, u)))
      hadRef.current = true
    } else if (hadRef.current) {
      setText('')
      hadRef.current = false
    }
    setError(null)
  }, [date, existing, u])

  const parsed = parseWeightInput(text)
  const warning = useMemo(() => {
    if (parsed == null || !isValidISO(date)) return null
    const kg = unitToKg(parsed, u)
    const prev = [...entries].reverse().find((e) => e.date < date)
    if (prev && Math.abs(kg - prev.kg) > 5)
      return `Este valor difiere más de ${fmtNum(kgToUnit(5, u), 0, 0)} ${u} del registro anterior (${fmtWeight(prev.kg, u)}). Verificá que sea correcto.`
    return null
  }, [parsed, date, entries, u])

  const step = (delta: number) => {
    const base = parsed ?? (entries.length ? kgToUnit(entries[entries.length - 1].kg, u) : u === 'kg' ? 70 : 154)
    const next = Math.round((base + delta) * 100) / 100
    setText(toInputString(Math.max(0, next)))
    setError(null)
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (!isValidISO(date)) return setError('Elegí una fecha válida.')
    if (date > today) return setError('La fecha no puede ser futura.')
    if (date < '2000-01-01') return setError('La fecha es demasiado antigua.')
    if (parsed == null) return setError('Ingresá un peso válido, por ejemplo 82,5 (hasta 2 decimales).')
    const kg = roundKg(unitToKg(parsed, u))
    if (kg < MIN_KG || kg > MAX_KG)
      return setError(
        `El peso debe estar entre ${fmtNum(kgToUnit(MIN_KG, u), 0, 0)} y ${fmtNum(kgToUnit(MAX_KG, u), 0, 0)} ${u}.`,
      )
    setSaving(true)
    try {
      await upsert(date, kg)
      toast(existing ? 'Registro actualizado' : 'Registro guardado')
    } catch {
      setError('No se pudo guardar. Intentá de nuevo.')
    } finally {
      setSaving(false)
    }
  }

  const recent = useMemo(() => [...entries].reverse().slice(0, 6), [entries])

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle title="Registrar peso" subtitle={isValidISO(date) ? formatLong(date) : undefined} />

      <form onSubmit={submit} noValidate>
        <Card className="!p-5 space-y-5">
          <div>
            <label htmlFor="weight" className="text-xs text-muted">
              Peso ({u})
            </label>
            <div className="mt-2 flex items-center gap-2">
              <Button type="button" aria-label="Restar 0,1" className="!w-12 !px-0 text-xl" onClick={() => step(-0.1)}>
                −
              </Button>
              <div className="relative flex-1">
                <input
                  id="weight"
                  inputMode="decimal"
                  autoComplete="off"
                  placeholder={u === 'kg' ? '82,5' : '181,9'}
                  value={text}
                  onChange={(e) => {
                    setText(e.target.value)
                    setError(null)
                  }}
                  className="w-full h-16 rounded-xl bg-card2 border border-line text-center text-4xl font-bold tabular-nums focus:outline-none focus:border-accent pr-12"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-muted text-sm">{u}</span>
              </div>
              <Button type="button" aria-label="Sumar 0,1" className="!w-12 !px-0 text-xl" onClick={() => step(0.1)}>
                +
              </Button>
            </div>
          </div>

          <div>
            <label htmlFor="date" className="text-xs text-muted">
              Fecha
            </label>
            <input
              id="date"
              type="date"
              max={today}
              min="2000-01-01"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-2 w-full h-12 rounded-xl bg-card2 border border-line px-3 focus:outline-none focus:border-accent"
            />
            {existing && (
              <p className="mt-2 text-xs text-blue">
                Ya hay un registro para esta fecha ({fmtWeight(existing.kg, u)}). Al guardar se actualiza, no se duplica.
              </p>
            )}
          </div>

          {warning && <p className="text-xs text-amber-300">{warning}</p>}
          {error && (
            <p role="alert" className="text-sm text-red-400">
              {error}
            </p>
          )}

          <div className="grid gap-3">
            <Button type="submit" variant="primary" disabled={saving}>
              {existing ? 'Actualizar registro' : 'Guardar registro'}
            </Button>
            {existing && (
              <Button type="button" variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => setConfirmDel(true)}>
                Eliminar este registro
              </Button>
            )}
          </div>
        </Card>
      </form>

      {recent.length > 0 && (
        <div>
          <SectionTitle>Últimos registros</SectionTitle>
          <div className="flex flex-wrap gap-2">
            {recent.map((e) => (
              <button
                key={e.date}
                onClick={() => setDate(e.date)}
                className={`rounded-xl border px-3 py-2 text-sm transition active:scale-95 ${
                  e.date === date ? 'border-accent bg-accent/10' : 'border-line bg-card'
                }`}
              >
                <span className="text-muted">{formatRow(e.date)}</span>{' '}
                <span className="font-semibold tabular-nums">{fmtWeight(e.kg, u)}</span>
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted">Tocá uno para editarlo.</p>
        </div>
      )}

      <ConfirmDialog
        open={confirmDel}
        danger
        title="¿Eliminar este registro?"
        message={`Se borrará el peso del ${isValidISO(date) ? formatLong(date) : date}. Los promedios se recalculan solos.`}
        confirmLabel="Eliminar"
        onCancel={() => setConfirmDel(false)}
        onConfirm={async () => {
          setConfirmDel(false)
          await remove(date)
          toast('Registro eliminado')
        }}
      />
    </div>
  )
}
