import type { Tab } from '../types'
import { useWeight } from '../store/WeightContext'
import EvolutionChart from '../components/EvolutionChart'
import WeeklyChart from '../components/WeeklyChart'
import WeekExplorer from '../components/WeekExplorer'
import { Button, EmptyState, PageTitle } from '../components/ui'
import { ChartIcon } from '../components/Icons'

export default function Stats({ go }: { go: (t: Tab) => void }) {
  const { entries } = useWeight()

  if (!entries.length) {
    return (
      <div className="animate-fade-up">
        <PageTitle title="Estadísticas" />
        <EmptyState
          icon={<ChartIcon />}
          title="Sin datos para graficar"
          text="Registrá tu peso unos días y acá vas a ver tu evolución y los promedios por semana."
        >
          <Button variant="primary" onClick={() => go('registrar')}>
            Registrar peso
          </Button>
        </EmptyState>
      </div>
    )
  }

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle title="Estadísticas" subtitle="Evolución diaria y promedios por semana" />
      <EvolutionChart />
      <WeeklyChart />
      <WeekExplorer />
    </div>
  )
}
