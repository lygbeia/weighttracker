import type { Settings, WeightEntry } from '../types'

const DB_NAME = 'weighttrack'
const DB_VERSION = 1
let dbPromise: Promise<IDBDatabase> | null = null

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB no disponible'))
      return
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains('entries')) db.createObjectStore('entries', { keyPath: 'date' })
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' })
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => {
      dbPromise = null
      reject(req.error)
    }
  })
  return dbPromise
}

async function run<T = undefined>(
  stores: string[],
  mode: IDBTransactionMode,
  fn: (tx: IDBTransaction) => IDBRequest | void,
): Promise<T> {
  const db = await openDB()
  return new Promise<T>((resolve, reject) => {
    const tx = db.transaction(stores, mode)
    const req = fn(tx)
    tx.oncomplete = () => resolve((req ? (req as IDBRequest).result : undefined) as T)
    tx.onerror = () => reject(tx.error)
    tx.onabort = () => reject(tx.error)
  })
}

export const getAllEntries = () =>
  run<WeightEntry[]>(['entries'], 'readonly', (tx) => tx.objectStore('entries').getAll())

export const putEntries = (list: WeightEntry[]) =>
  run(['entries'], 'readwrite', (tx) => {
    const s = tx.objectStore('entries')
    list.forEach((e) => s.put(e))
  })

export const deleteEntries = (dates: string[]) =>
  run(['entries'], 'readwrite', (tx) => {
    const s = tx.objectStore('entries')
    dates.forEach((d) => s.delete(d))
  })

export const clearEntries = () =>
  run(['entries'], 'readwrite', (tx) => tx.objectStore('entries').clear())

export async function getSettings(): Promise<Settings | null> {
  const r = await run<{ key: string; value: Settings } | undefined>(['meta'], 'readonly', (tx) =>
    tx.objectStore('meta').get('settings'),
  )
  return r?.value ?? null
}

export const saveSettings = (value: Settings) =>
  run(['meta'], 'readwrite', (tx) => tx.objectStore('meta').put({ key: 'settings', value }))

/** Reemplaza todos los registros en una sola transacción. */
export const replaceEntries = (list: WeightEntry[]) =>
  run(['entries'], 'readwrite', (tx) => {
    const s = tx.objectStore('entries')
    s.clear()
    list.forEach((e) => s.put(e))
  })
