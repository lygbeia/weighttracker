import type { WeekStart, WeekSummary, WeightEntry } from '../types'
import { addDays, weekStartOf } from './dates'

/** Variación (en kg) por debajo de la cual se considera "estable". */
export const STABLE_KG = 0.2
export type Trend = 'up' | 'down' | 'stable'

export const trendOf = (diffKg: number): Trend =>
  Math.abs(diffKg) < STABLE_KG ? 'stable' : diffKg > 0 ? 'up' : 'down'

function build(start: string, list: WeightEntry[]): WeekSummary {
  const kgs = list.map((e) => e.kg)
  // Promedio = suma de los registros reales / cantidad de registros. Nunca se rellenan días.
  const avg = kgs.reduce((a, b) => a + b, 0) / kgs.length
  return {
    start,
    end: addDays(start, 6),
    count: list.length,
    avg,
    min: Math.min(...kgs),
    max: Math.max(...kgs),
    entries: list,
  }
}

export const entriesBetween = (entries: WeightEntry[], from: string, to: string) =>
  entries.filter((e) => e.date >= from && e.date <= to)

/** Resumen de la semana que empieza en `start`, o null si no hay registros. */
export function summarizeWeek(entries: WeightEntry[], start: string): WeekSummary | null {
  const list = entriesBetween(entries, start, addDays(start, 6))
  return list.length ? build(start, list) : null
}

/** Todas las semanas con al menos un registro, de la más antigua a la más reciente. */
export function groupByWeek(entries: WeightEntry[], ws: WeekStart): WeekSummary[] {
  const map = new Map<string, WeightEntry[]>()
  for (const e of entries) {
    const k = weekStartOf(e.date, ws)
    const arr = map.get(k)
    if (arr) arr.push(e)
    else map.set(k, [e])
  }
  return [...map.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)).map(([s, l]) => build(s, l))
}
