import type { WeekStart } from '../types'

const pad = (n: number) => String(n).padStart(2, '0')
export const DAY_MS = 86400000

/** Fecha local del dispositivo como YYYY-MM-DD. */
export function toISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
export const todayISO = () => toISO(new Date())

export function isValidISO(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false
  const [y, m, d] = s.split('-').map(Number)
  const dt = new Date(Date.UTC(y, m - 1, d))
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d
}

/** ISO -> milisegundos UTC a medianoche (aritmética sin problemas de zona horaria). */
export function dateToMs(s: string): number {
  const [y, m, d] = s.split('-').map(Number)
  return Date.UTC(y, m - 1, d)
}

export function addDays(s: string, n: number): string {
  const t = new Date(dateToMs(s) + n * DAY_MS)
  return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}`
}

export const diffDays = (a: string, b: string) => Math.round((dateToMs(a) - dateToMs(b)) / DAY_MS)

/** Primer día de la semana que contiene a `s`. */
export function weekStartOf(s: string, weekStart: WeekStart): string {
  const dow = new Date(dateToMs(s)).getUTCDay()
  return addDays(s, -((dow - weekStart + 7) % 7))
}

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)
const fmt = (o: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat('es-AR', { ...o, timeZone: 'UTC' })

const longFmt = fmt({ weekday: 'long', day: 'numeric', month: 'long' })
const longYearFmt = fmt({ weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
const shortFmt = fmt({ day: 'numeric', month: 'short' })
const shortYearFmt = fmt({ day: 'numeric', month: 'short', year: 'numeric' })
const rowFmt = fmt({ weekday: 'short', day: 'numeric', month: 'short' })

const at = (s: string) => new Date(dateToMs(s))
const sameYear = (s: string) => s.slice(0, 4) === todayISO().slice(0, 4)

/** "Lunes, 9 de noviembre" (con año si no es el actual). */
export const formatLong = (s: string) =>
  cap((sameYear(s) ? longFmt : longYearFmt).format(at(s)).replace(',', ''))
/** "9 nov" (con año si no es el actual). */
export const formatShort = (s: string) => (sameYear(s) ? shortFmt : shortYearFmt).format(at(s))
/** "lun, 9 nov" para filas de lista. */
export const formatRow = (s: string) => cap(rowFmt.format(at(s)).replace(',', ''))

/** "9 – 15 nov" / "28 oct – 3 nov". */
export function formatWeekRange(start: string): string {
  const end = addDays(start, 6)
  const a = at(start)
  const b = at(end)
  const sameMonth = a.getUTCMonth() === b.getUTCMonth()
  const left = sameMonth ? String(a.getUTCDate()) : shortFmt.format(a)
  const right = sameYear(end) ? shortFmt.format(b) : shortYearFmt.format(b)
  return `${left} – ${right}`
}

export function relativeDay(s: string, today: string): string {
  const n = diffDays(today, s)
  if (n === 0) return 'hoy'
  if (n === 1) return 'ayer'
  if (n > 1) return `hace ${n} días`
  return formatShort(s)
}

export const weekdayLabel = (w: WeekStart) =>
  w === 1 ? 'Lunes' : w === 0 ? 'Domingo' : 'Sábado'
