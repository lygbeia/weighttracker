import type { Settings, WeightEntry } from '../types'
import { addDays, isValidISO, todayISO } from './dates'
import { MAX_KG, MIN_KG, roundKg } from './units'

/* ---------- CSV ---------- */

/** Separador ";" y coma decimal: se abre bien en Excel/Sheets con configuración regional argentina. */
export function entriesToCSV(entries: WeightEntry[]): string {
  const lines = ['fecha;peso_kg']
  for (const e of entries) lines.push(`${e.date};${String(roundKg(e.kg)).replace('.', ',')}`)
  return '﻿' + lines.join('\r\n') + '\r\n'
}

export interface ParsedCSV {
  rows: { date: string; kg: number }[]
  skipped: number
  errors: string[]
}

function parseDate(s: string): string | null {
  const t = s.trim()
  let iso: string | null = null
  const a = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(t)
  const b = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(t) // día/mes/año (formato argentino)
  const p = (n: string) => n.padStart(2, '0')
  if (a) iso = `${a[1]}-${p(a[2])}-${p(a[3])}`
  else if (b) iso = `${b[3]}-${p(b[2])}-${p(b[1])}`
  return iso && isValidISO(iso) ? iso : null
}

function parseKg(s: string): number | null {
  const t = s.trim().replace(/^"|"$/g, '').replace(',', '.')
  if (!/^\d{1,3}(\.\d+)?$/.test(t)) return null
  const n = Number(t)
  return n >= MIN_KG && n <= MAX_KG ? roundKg(n) : null
}

export function parseCSV(text: string): ParsedCSV {
  const lines = text
    .replace(/^﻿/, '')
    .split(/\r?\n/)
    .filter((l) => l.trim() !== '')
  const result: ParsedCSV = { rows: [], skipped: 0, errors: [] }
  if (!lines.length) return result

  const first = lines[0]
  const delim = first.includes(';') ? ';' : first.includes('\t') ? '\t' : ','
  const today = todayISO()
  const byDate = new Map<string, number>()

  lines.forEach((line, i) => {
    const fields = line.split(delim).map((f) => f.trim().replace(/^"|"$/g, ''))
    // Con separador "," y coma decimal sin comillas, el peso queda partido en varios campos.
    const weightRaw = delim === ',' ? fields.slice(1).join(',') : fields[1] ?? ''
    const date = parseDate(fields[0] ?? '')
    if (!date) {
      if (i === 0) return // encabezado
      result.skipped++
      if (result.errors.length < 5) result.errors.push(`Línea ${i + 1}: fecha no válida`)
      return
    }
    const kg = parseKg(weightRaw)
    if (kg == null) {
      result.skipped++
      if (result.errors.length < 5)
        result.errors.push(`Línea ${i + 1}: peso fuera de rango o con formato no válido`)
      return
    }
    if (date > today) {
      result.skipped++
      if (result.errors.length < 5) result.errors.push(`Línea ${i + 1}: fecha futura`)
      return
    }
    byDate.set(date, kg) // si una fecha se repite, gana la última
  })

  result.rows = [...byDate.entries()].map(([date, kg]) => ({ date, kg }))
  return result
}

/* ---------- Copia de seguridad (JSON) ---------- */

export interface Backup {
  app: 'WeightTrack'
  version: 1
  exportedAt: string
  settings: Settings
  entries: WeightEntry[]
}

export function makeBackup(entries: WeightEntry[], settings: Settings): string {
  const b: Backup = {
    app: 'WeightTrack',
    version: 1,
    exportedAt: new Date().toISOString(),
    settings,
    entries,
  }
  return JSON.stringify(b, null, 2)
}

export function parseBackup(text: string): { entries: WeightEntry[]; settings: Settings | null } {
  let obj: any
  try {
    obj = JSON.parse(text)
  } catch {
    throw new Error('El archivo no es una copia de seguridad válida.')
  }
  if (!obj || obj.app !== 'WeightTrack' || !Array.isArray(obj.entries))
    throw new Error('El archivo no parece una copia de seguridad de WeightTrack.')
  const today = todayISO()
  const map = new Map<string, WeightEntry>()
  for (const e of obj.entries) {
    if (
      e &&
      typeof e.date === 'string' &&
      isValidISO(e.date) &&
      e.date <= addDays(today, 0) &&
      typeof e.kg === 'number' &&
      e.kg >= MIN_KG &&
      e.kg <= MAX_KG
    ) {
      map.set(e.date, {
        date: e.date,
        kg: roundKg(e.kg),
        updatedAt: typeof e.updatedAt === 'number' ? e.updatedAt : Date.now(),
        ...(e.demo ? { demo: true } : {}),
      })
    }
  }
  let settings: Settings | null = null
  const s = obj.settings
  if (s && (s.unit === 'kg' || s.unit === 'lb') && [0, 1, 6].includes(s.weekStart))
    settings = { unit: s.unit, weekStart: s.weekStart }
  return { entries: [...map.values()], settings }
}

/* ---------- Descarga ---------- */

export function downloadFile(name: string, mime: string, content: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }))
  const a = document.createElement('a')
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
