import type { Unit } from '../types'

const LB_PER_KG = 2.2046226218
export const MIN_KG = 20
export const MAX_KG = 400

export const kgToUnit = (kg: number, u: Unit) => (u === 'kg' ? kg : kg * LB_PER_KG)
export const unitToKg = (v: number, u: Unit) => (u === 'kg' ? v : v / LB_PER_KG)

/** Formato argentino: coma decimal, punto de miles. */
export function fmtNum(n: number, min = 1, max = 2): string {
  return n.toLocaleString('es-AR', { minimumFractionDigits: min, maximumFractionDigits: max })
}

/** Peso individual: entre 1 y 2 decimales. */
export const fmtWeight = (kg: number, u: Unit) => `${fmtNum(kgToUnit(kg, u), 1, 2)} ${u}`
/** Promedio: siempre 2 decimales. */
export const fmtAvg = (kg: number, u: Unit) => `${fmtNum(kgToUnit(kg, u), 2, 2)} ${u}`

/** Diferencia con signo, siempre 2 decimales. */
export function fmtDelta(deltaKg: number, u: Unit): string {
  const r = Math.round(kgToUnit(deltaKg, u) * 100) / 100
  const sign = r > 0 ? '+' : r < 0 ? '−' : ''
  return `${sign}${fmtNum(Math.abs(r), 2, 2)} ${u}`
}
export const fmtAbs = (deltaKg: number, u: Unit) =>
  `${fmtNum(Math.abs(kgToUnit(deltaKg, u)), 2, 2)} ${u}`

/** Interpreta "82,5" o "82.5". Devuelve null si el formato no es válido. */
export function parseWeightInput(text: string): number | null {
  const s = text.trim().replace(',', '.')
  if (!/^\d{1,3}(\.\d{1,2})?$/.test(s)) return null
  const n = Number(s)
  return Number.isFinite(n) ? n : null
}

/** Para precargar el input: "82,5". */
export const toInputString = (n: number) => String(Math.round(n * 100) / 100).replace('.', ',')

export const roundKg = (kg: number) => Math.round(kg * 1000) / 1000
