import type { WeightEntry } from '../types'
import { addDays } from './dates'

/**
 * Datos de DEMOSTRACIÓN (marcados con demo: true). Son ficticios, con días sin registro a propósito,
 * y se pueden eliminar desde Inicio o Configuración sin tocar los registros reales.
 */
export function generateDemo(today: string): WeightEntry[] {
  let seed = 20260101
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296
    return seed / 4294967296
  }
  const days = 63
  const out: WeightEntry[] = []
  for (let i = days - 1; i >= 0; i--) {
    if (rnd() < 0.22) continue // días sin registro
    const trend = 83.4 - 0.025 * (days - 1 - i)
    const kg = Math.round((trend + (rnd() - 0.5) * 0.9) * 10) / 10
    out.push({ date: addDays(today, -i), kg, demo: true, updatedAt: Date.now() })
  }
  return out
}
