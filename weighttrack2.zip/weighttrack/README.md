# WeightTrack

App web (PWA) de seguimiento de peso corporal: registro diario, **promedios semanales**, gráficos e historial. Funciona en tu dispositivo, **sin conexión**, sin cuentas ni servidores.

Stack: React 18 · TypeScript · Tailwind CSS 3 · Recharts · Vite 5 · vite-plugin-pwa (Workbox).

---

## 1. Ejecutarla en tu computadora

Requisitos: [Node.js](https://nodejs.org) 18 o superior (recomendado 20).

```bash
npm install
npm run dev        # desarrollo (el service worker está desactivado a propósito)
```

Para probar la **versión PWA real** (service worker + offline) hay que compilar:

```bash
npm run build      # verifica tipos y genera dist/ con sw.js y manifest.webmanifest
npm run preview    # sirve dist/ en http://localhost:4173
```

En Chrome de escritorio: `F12` → pestaña **Application** → *Manifest* (iconos e instalabilidad) y *Service Workers*. Marcá *Offline* y recargá: la app debe seguir abriendo.

> `npm install` crea `package-lock.json`. **Subilo a GitHub** (así Netlify instala exactamente las mismas versiones).

---

## 2. Publicarla gratis en Netlify mediante GitHub

### a) Subir el proyecto a GitHub
1. Creá una cuenta en <https://github.com> si no tenés.
2. **New repository** → nombre `weighttrack` → *Private* o *Public* (ambos sirven) → **Create repository**. No marques «Add a README».
3. En la carpeta del proyecto:
   ```bash
   git init
   git add .
   git commit -m "WeightTrack PWA"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/weighttrack.git
   git push -u origin main
   ```
   (`node_modules/` y `dist/` ya están en `.gitignore`.)

### b) Conectar Netlify
1. Entrá a <https://app.netlify.com> y registrate con **Continue with GitHub** (plan Free, sin tarjeta).
2. **Add new site → Import an existing project → GitHub** y autorizá el acceso al repositorio `weighttrack`.
3. La configuración ya viene en `netlify.toml`; verificá que figure:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. **Deploy**. En 1–2 minutos tenés una URL tipo `https://nombre-aleatorio.netlify.app`.
5. (Opcional) *Site configuration → Change site name* para elegir `https://weighttrack-tunombre.netlify.app`.

Cada `git push` a `main` vuelve a publicar solo. La app instalada se actualiza en la siguiente apertura con conexión.

---

## 3. Instalarla en tu Google Pixel 7 (Chrome)

1. Abrí tu URL de Netlify **en Chrome** (tiene que ser `https://`, que Netlify ya te da).
2. Esperá unos segundos a que cargue completa (el service worker se instala y guarda la app para uso sin conexión).
3. Instalá, de cualquiera de estas formas:
   - Botón **Instalar WeightTrack** en *Configuración* dentro de la app (aparece cuando Chrome la considera instalable), o
   - Menú **⋮ → Agregar a la pantalla principal → Instalar**, o
   - el aviso «Instalar app» que Chrome puede mostrar abajo.
4. Se crea el icono de WeightTrack en tu pantalla de inicio y en el cajón de apps. Se abre en pantalla completa, sin barra del navegador, y funciona en modo avión.

**Importante sobre tus datos**
- Los registros se guardan en IndexedDB del navegador, ligados a **esa URL exacta**. Si cambiás el nombre del sitio de Netlify después de cargar datos, la app nueva empieza vacía: antes de cambiarlo, exportá en *Configuración → Copia de seguridad* y restaurá en la nueva URL.
- Si borrás los datos de Chrome / de la app, se pierden. Hacé una copia de seguridad cada tanto.
- La app instalada y la pestaña de Chrome **comparten** los datos de ese mismo sitio.

---

## 4. Qué se agregó para la PWA

| Pieza | Dónde |
|---|---|
| Service worker (Workbox, precache de toda la app, `navigateFallback`, limpieza de cachés viejas, actualización automática) | `vite.config.ts` → `VitePWA({...})` → genera `dist/sw.js` |
| Manifest (nombre, `standalone`, colores, `scope`/`start_url` `/`, iconos) | `vite.config.ts` → genera `dist/manifest.webmanifest` |
| Iconos 192×192, 512×512 y **maskable** 512×512 (más Apple 180×180 y favicon) | `public/*.png` |
| Botón «Instalar WeightTrack» | `src/lib/useInstall.ts`, `src/pages/Settings.tsx` |
| Cabeceras de caché (el `sw.js` nunca se cachea; `/assets/*` sí) y SPA fallback | `netlify.toml` |
| Build de producción: `base: '/'`, chunks separados para React y Recharts | `vite.config.ts` |

Todo lo anterior es adicional: la lógica de promedios, IndexedDB, CSV, copias de seguridad, datos demo y la interfaz no cambiaron.

### Cambiar los iconos
Reemplazá los PNG de `public/` manteniendo nombre y tamaño (`pwa-192x192.png`, `pwa-512x512.png`, `maskable-512x512.png`, `apple-touch-icon.png`). Para el *maskable*, dejá el dibujo dentro del 60 % central: Android lo recorta con forma de círculo/cuadrado redondeado.

### Si la app instalada no se actualiza
Cerrala del todo (deslizar fuera de recientes) y abrila con conexión; el nuevo service worker toma el control en la siguiente apertura.

---

## Cómo funciona la app

- **Promedio semanal** = suma de los pesos registrados en la semana ÷ cantidad de registros. No hace falta tener 7 y **nunca se rellenan días faltantes**. Semana sin registros → estado vacío.
- Semanas de lunes a domingo por defecto (configurable: domingo o sábado).
- «Estable» = diferencia entre promedios menor a 0,2 kg (`STABLE_KG` en `src/lib/stats.ts`).
- Un registro por fecha: guardar sobre una fecha existente la actualiza.
- Pesos guardados siempre en kg; kg/lb solo cambia la visualización. Coma decimal (`82,5`) y fechas en español.
- **CSV**: `fecha;peso_kg` (separador `;`, coma decimal). Al importar acepta `;` `,` o tabulación, fechas `AAAA-MM-DD` o `DD/MM/AAAA`.
- **Copia de seguridad** JSON: registros + ajustes; «Restaurar copia» reemplaza todo.
- **Datos demo**: ficticios, marcados «DEMO», nunca pisan registros reales y se eliminan con un botón.

## Estructura

```
public/        iconos PNG/SVG
src/
  lib/         dates, units, stats, db (IndexedDB), csv/backup, demo, useInstall
  store/       WeightContext
  components/  BottomNav, ConfirmDialog, Toast, gráficos, ui, Icons
  pages/       Dashboard, Register, Stats, History, Settings
netlify.toml   build, cabeceras de caché y SPA fallback
vite.config.ts Vite + PWA
```
